﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarmPolymorphismExercise
{
    public interface IFood
    {
        public int Quantity { get; }
    }
}
